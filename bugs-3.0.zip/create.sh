#cat ~/jdksec/Payloads/Master.txt > bugs.txt
web-ext build --overwrite-dest
